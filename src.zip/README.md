### Hello
### I advise you to use LunCore it is safe

<!--
**LunCore/LunCore** is a ✨ _special_ ✨ repository because its `README.md` (this file) appears on your GitHub profile.

LunCore - the core of the future

- 🔭 I'm currently working on LunCore
-->



### Привет
### Советую использовать LunCore, это безопасно


<!--
** LunCore / LunCore ** - это ✨ _special_ ✨ репозиторий, потому что его `README.md` (этот файл) отображается в вашем профиле GitHub.

LunCore - ядро ​​будущего

- 🔭 Советую использовать LunCore, это безопасно
-->
